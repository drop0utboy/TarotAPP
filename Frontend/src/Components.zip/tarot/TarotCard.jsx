// Components/tarot/TarotCard.jsx
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";

/**
 * props
 * ─────────────────────────────────────────────
 * card       : { name, suit, imageUrl }  // imageUrl 없으면 글자/그라디언트로 대체
 * isRevealed : 부모 컴포넌트가 관리하는 공개 여부
 * onReveal   : flip 애니메이션 끝난 뒤 호출될 콜백
 * position   : "left" | "center" | "right" → 카드뒷면 색상용
 * delay      : initial fade-in 지연(sec)
 */
export default function TarotCard({
  card,
  isRevealed,
  onReveal,
  position = "center",
  delay = 0,
}) {
  /* 내부 상태는 클릭(뒤집기) 애니메이션용 */
  const [isFlipped, setIsFlipped] = useState(false);

  const handleClick = () => {
    if (!isRevealed) {
      setIsFlipped(true);
      /* flip 애니메이션(0.6s) 후 부모에 알림 */
      setTimeout(() => onReveal?.(), 600);
    }
  };

  /* 카드 뒷면 그라디언트 팔레트 */
  const cardBacks = {
    left:  "bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-800",
    center:"bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900",
    right: "bg-gradient-to-br from-purple-800 via-indigo-800 to-purple-900",
  };

  /* 카드 앞면 콘텐츠 (이미지 or 플레이스홀더) */
  const FrontContent = () =>
    card?.imageUrl ? (
      <img
        src={card.imageUrl}
        alt={card.name}
        className="object-cover w-full h-full"
        onError={(e) => (e.currentTarget.style.display = "none")} /* 404 대비 */
      />
    ) : (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="w-16 h-16 mb-3 rounded-full bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center">
          <span className="text-white font-bold text-lg">
            {card?.name?.charAt(0) || "?"}
          </span>
        </div>
        <div className="space-y-1 w-3/4">
          <div className="h-2 bg-gradient-to-r from-purple-400 to-indigo-500 rounded" />
          <div className="h-1 bg-gradient-to-r from-amber-400 to-yellow-500 rounded" />
          <div className="h-2 bg-gradient-to-r from-purple-400 to-indigo-500 rounded" />
        </div>
      </div>
    );

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay }}
      className="relative"
    >
      <div
        className={`relative w-32 h-48 md:w-40 md:h-60 cursor-pointer transition-transform duration-300 ${
          !isRevealed ? "hover:scale-105 hover:shadow-2xl" : ""
        }`}
        style={{ perspective: "1000px" }}
        onClick={handleClick}
      >
        <motion.div
          className="relative w-full h-full"
          style={{ transformStyle: "preserve-3d" }}
          animate={{ rotateY: isFlipped || isRevealed ? 180 : 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* ───── Back ───── */}
          <Card
            className={`absolute inset-0 w-full h-full ${
              cardBacks[position]
            } mystical-border card-glow`}
            style={{ backfaceVisibility: "hidden" }}
          >
            <div className="flex items-center justify-center h-full">
              <div className="text-center space-y-2">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-yellow-400" />
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="h-1 w-12 bg-gradient-to-r from-yellow-400 to-amber-500 rounded mx-auto" />
                  <div className="h-1 w-8  bg-gradient-to-r from-purple-400 to-indigo-500 rounded mx-auto" />
                  <div className="h-1 w-12 bg-gradient-to-r from-yellow-400 to-amber-500 rounded mx-auto" />
                </div>
              </div>
            </div>
          </Card>

          {/* ───── Front ───── */}
          <Card
            className="absolute inset-0 w-full h-full bg-slate-50 mystical-border overflow-hidden"
            style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
          >
            <FrontContent />

            <div className="absolute bottom-2 inset-x-0 text-center px-2">
              <h3 className="font-bold text-gray-800 text-sm truncate">
                {card?.name || "Mystery Card"}
              </h3>
              <p className="text-xs text-gray-600 mt-0.5">
                {card?.suit || "Major Arcana"}
              </p>
            </div>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
